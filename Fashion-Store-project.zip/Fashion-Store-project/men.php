<?php
session_start();
if($_SESSION['user_email']=="")
{
    header("location:index.php");
}

include("connection.php");
$cus_email=$_REQUEST['reg_email'];
error_reporting(1);

extract($_POST);
if($sub1)
{
    mysql_query("
        CREATE TABLE feedbacks
        (
            Name VARCHAR(20) NOT NULL,
            Email VARCHAR(30) NOT NULL,
            Feedback VARCHAR(70) NOT NULL
        )
    ");

    if(mysql_query("INSERT INTO feedbacks VALUES('$name','$email','$feedback')"))
    {
        header("refresh:0");
    }
}
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link href="css/templatemo-ebook-landing.css" rel="stylesheet">

    </head>
    
    <body>

        <main>

            <div class= "navmain"><nav class="navbar navbar-expand-lg">
                <div class="container">
                    <a id="logo" class="navbar-brand" href="index.php">
                        <image src="image/letter-a1.png" height="70%" width="70%">
                    </a>
                    <a class="navbar-brand" href="index.php">
                        <span id="com-name">Arbarr Arbarr</span>
                    </a>

                    <p>Your account is registered</p>
    
                    <div class="collapse navbar-collapse" id="navbarNav">

                        <div id="vap" class="d-none d-lg-block">
                            <a href="logout.php" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                <i class="btn-icon bi-box-arrow-right"></i>
                                <span>Log out</span>
                            </a>
                        </div>
                    </div>
                </div>
            </nav></div>
            

            <section class="hero-section d-flex justify-content-center align-items-center" id="home">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12 mb-5 pb-5 pb-lg-0 mb-lg-0">

                            <h6 id="h61">Your Fashion, Your Choice</h6>

                            <a href="registered.php?reg_email=<?php echo $cus_email; ?>" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">Latest Products</a>

                            <a href="#contact" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">Contact Us</a>
                        </div>

                        <div class="hero-image-wrap col-lg-6 col-12 mt-3 mt-lg-0">
                            <img src="image/pre.jpg" width="400px" height="800px" style="border:5px solid var(--custom-btn-bg-color); border-radius: 10px;" class="hero-image img-fluid" alt="fashion">
                        </div>

                    </div>
                </div>
            </section>


            <section class="featured-section">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-8 col-12">
                            <div class="avatar-group d-flex flex-wrap align-items-center">
                                <img src="images/avatar/portrait-beautiful-young-woman-standing-grey-wall.jpg" class="img-fluid avatar-image" alt="profile">

                                <img src="images/avatar/portrait-young-redhead-bearded-male.jpg" class="img-fluid avatar-image avatar-image-left" alt="profile">

                                <img src="images/avatar/pretty-blonde-woman.jpg" class="img-fluid avatar-image avatar-image-left" alt="profile">

                                <img src="images/avatar/studio-portrait-emotional-happy-funny-smiling-boyfriend.jpg" class="img-fluid avatar-image avatar-image-left" alt="profile">

                                <div class="reviews-group mt-3 mt-lg-0">
                                    <strong>4.5</strong>

                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star"></i>

                                    <small class="ms-3">2,564 reviews</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="py-lg-5"></section>

            <section>
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12 text-center">
                            <h6 style="padding-right: 650px; font-size: xx-large;">Heres are <strong><i>Men Fashion</i></strong></h6>
                            
                            <a style="background-color:#F4A261; color:white; border:none;" id="products" class="btn custom-btn smoothscroll me-3">Men Fashion</a>
                            <a href="women.php?reg_email=<?php echo $cus_email; ?>" class="btn custom-btn smoothscroll me-3">Women Fashion</a>
                        </div>

                        <div class="col-lg-4 col-12" >
                            <nav id="navbar-example3" class="h-100 flex-column align-items-stretch">
                                <nav class="nav nav-pills flex-column">

                                    <a class="nav-link smoothscroll" href="#item-1"><strong>Street Fashion</strong></a>

                                    <a class="nav-link smoothscroll" href="#item-2"><strong>Classic Fashion</strong></a>

                                    <a class="nav-link smoothscroll" href="#item-3"><strong>Cyber Fashion</strong></a>

                                    <a class="nav-link smoothscroll" href="#item-4"><strong>Hiphop Fashion</strong></a>

                                    <a class="nav-link smoothscroll" href="#item-5"><strong>Business Casual</strong></a>
                                </nav>
                            </nav>
                        </div>

                        <div class="col-lg-8 col-12">
                            <div data-bs-spy="scroll" data-bs-target="#navbar-example3" data-bs-smooth-scroll="true" class="scrollspy-example-2" tabindex="0">
                                
                                <div class="scrollspy-example-item" id="item-1">

                                    <h3 align="center" style="color:#F4A261;">Street Fashion</h3>
                                    <?php
                                        $data1=mysql_query("SELECT * FROM products WHERE Category='Street' AND NOT Gender='women' ORDER BY ID DESC");
                                        echo "<table border='0' width='100%' align='center'><tr>";
                                        @$incre=0;
                                        while($arr1=mysql_fetch_assoc($data1))
                                        {
                                            if($incre%2==0)
                                            {
                                                echo "<tr>";
                                            }
                                    ?>

                                    <td id="productdiv">
                                    <a href="order.php?pd_id=<?php echo $arr1['ID']; ?> & reg_email=<?php echo $cus_email;?>">
                                            <?php echo "<img id='productimage' src='image/product_images/".$arr1["Image"]."'"; ?><br>
                                            <p><?php echo $arr1['Product_name']; ?></p>
                                            <p><?php echo $arr1['Price']." ks"; ?></p>
                                        </a>
                                    </td>

                                    <?php                                            
                                            $incre++;
                                        }
                                        echo "</tr></table>";
                                    ?>

                                </div>

                                <div class="scrollspy-example-item" id="item-2">

                                    <h3 align="center" style="color:#F4A261;">Classic Fashion</h3>
                                    <?php
                                        $data1=mysql_query("SELECT * FROM products WHERE Category='Classic' AND NOT Gender='women' ORDER BY ID DESC");
                                        echo "<table border='0' width='100%' align='center'><tr>";
                                        @$incre=0;
                                        while($arr1=mysql_fetch_assoc($data1))
                                        {
                                            if($incre%2==0)
                                            {
                                                echo "<tr>";
                                            }
                                    ?>

                                    <td id="productdiv">
                                    <a href="order.php?pd_id=<?php echo $arr1['ID']; ?> & reg_email=<?php echo $cus_email;?>">
                                            <?php echo "<img id='productimage' src='image/product_images/".$arr1["Image"]."'"; ?><br>
                                            <p><?php echo $arr1['Product_name']; ?></p>
                                            <p><?php echo $arr1['Price']." ks"; ?></p>
                                        </a>
                                    </td>

                                    <?php                                            
                                            $incre++;
                                        }
                                        echo "</tr></table>";
                                    ?>
                                    
                                </div>

                                <div class="scrollspy-example-item" id="item-3"> 

                                    <h3 align="center" style="color:#F4A261;">Cyber Fashion</h3>
                                    <?php
                                        $data1=mysql_query("SELECT * FROM products WHERE Category='Cyber' AND NOT Gender='women' ORDER BY ID DESC");
                                        echo "<table border='0' width='100%' align='center'><tr>";
                                        @$incre=0;
                                        while($arr1=mysql_fetch_assoc($data1))
                                        {
                                            if($incre%2==0)
                                            {
                                                echo "<tr>";
                                            }
                                    ?>

                                    <td id="productdiv">
                                    <a href="order.php?pd_id=<?php echo $arr1['ID']; ?> & reg_email=<?php echo $cus_email;?>">
                                            <?php echo "<img id='productimage' src='image/product_images/".$arr1["Image"]."'"; ?><br>
                                            <p><?php echo $arr1['Product_name']; ?></p>
                                            <p><?php echo $arr1['Price']." ks"; ?></p>
                                        </a>
                                    </td>

                                    <?php                                            
                                            $incre++;
                                        }
                                        echo "</tr></table>";
                                    ?>                                
                            
                                </div>

                                <div class="scrollspy-example-item" id="item-4">

                                    <h3 align="center" style="color:#F4A261;">Hiphop Fashion</h3>
                                    <?php
                                        $data1=mysql_query("SELECT * FROM products WHERE Category='Hiphop' AND NOT Gender='women' ORDER BY ID DESC");
                                        echo "<table border='0' width='100%' align='center'><tr>";
                                        @$incre=0;
                                        while($arr1=mysql_fetch_assoc($data1))
                                        {
                                            if($incre%2==0)
                                            {
                                                echo "<tr>";
                                            }
                                    ?>

                                    <td id="productdiv">
                                    <a href="order.php?pd_id=<?php echo $arr1['ID']; ?> & reg_email=<?php echo $cus_email;?>">
                                            <?php echo "<img id='productimage' src='image/product_images/".$arr1["Image"]."'"; ?><br>
                                            <p><?php echo $arr1['Product_name']; ?></p>
                                            <p><?php echo $arr1['Price']." ks"; ?></p>
                                        </a>
                                    </td>

                                    <?php                                            
                                            $incre++;
                                        }
                                        echo "</tr></table>";
                                    ?>

                                </div>

                                <div class="scrollspy-example-item" id="item-5">

                                    <h3 align="center" style="color:#F4A261;">Business Casual</h3>
                                    <?php
                                        $data1=mysql_query("SELECT * FROM products WHERE Category='Business' AND NOT Gender='women' ORDER BY ID DESC");
                                        echo "<table border='0' width='100%' align='center'><tr>";
                                        @$incre=0;
                                        while($arr1=mysql_fetch_assoc($data1))
                                        {
                                            if($incre%2==0)
                                            {
                                                echo "<tr>";
                                            }
                                    ?>

                                    <td id="productdiv">
                                    <a href="order.php?pd_id=<?php echo $arr1['ID']; ?> & reg_email=<?php echo $cus_email;?>">
                                            <?php echo "<img id='productimage' src='image/product_images/".$arr1["Image"]."'"; ?><br>
                                            <p><?php echo $arr1['Product_name']; ?></p>
                                            <p><?php echo $arr1['Price']." ks"; ?></p>
                                        </a>
                                    </td>

                                    <?php                                            
                                            $incre++;
                                        }
                                        echo "</tr></table>";
                                    ?>
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

            <section class="contact-section section-padding" id="contact">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-5 col-12 mx-auto">
                            <form class="custom-form ebook-download-form bg-white shadow" method="post" role="form">
                                <div class="text-center mb-5">
                                    <h2 class="mb-1">Give your feedback</h2>
                                </div>

                                <div class="ebook-download-form-body">
                                    <div class="input-group mb-4">
                                        <input type="text" name="name" id="ebook-form-name" class="form-control" aria-label="ebook-form-name" aria-describedby="basic-addon1" placeholder="Your Name" required>

                                        <span class="input-group-text" id="basic-addon1">
                                            <i class="custom-form-icon bi-person"></i>
                                        </span>
                                    </div>

                                    <div class="input-group mb-4">
                                        <input type="email" name="email" id="ebook-email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Your Email" aria-label="ebook-form-email" aria-describedby="basic-addon2" required="">

                                        <span class="input-group-text" id="basic-addon2">
                                            <i class="custom-form-icon bi-envelope"></i>
                                        </span>
                                    </div>

                                    <div class="input-group mb-4">
                                        <textarea name="feedback" id="ebook-email" class="form-control" placeholder="Your Feedback" aria-label="ebook-form-email" aria-describedby="basic-addon1" required=""></textarea>

                                    </div>

                                    <div class="col-lg-8 col-md-10 col-8 mx-auto">
                                        <input name="sub1" type="submit" id="sub" value="Send Mail" onclick="abc()"><br>
                                    </div>

                                    <script>
                                        function abc(){
                                            alert("Thank you for feedback.  It was sent sucessfully.");
                                        }
                                    </script>

                                    <div>
                                        <p><?php echo $fb_success; ?></p>
                                    </div>

                                </div>
                            </form>
                        </div>

                        <div class="col-lg-6 col-12">
                            <h6 style="color: rgb(255, 255, 255);">Say hi and talk to us</h6>

                            <h2 class="mb-4">Contact</h2>

                            <p class="mb-3">
                                <i class="bi-geo-alt me-2"></i>
                                Dagon Myothit(East), Yangon
                            </p>

                            <p class="mb-2">
                                <a href="tel: 010-020-0340" class="contact-link">
                                    099-839-110-65
                                </a>
                            </p>

                            <p>
                                <a href="mailto:arbarrarbarr@gmail.com" class="contact-link">
                                    arbarrarbarr@gmail.com
                                </a>
                            </p>

                            <h6 class="site-footer-title mt-5 mb-3">Social</h6>

                            <ul class="social-icon mb-4">
                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-instagram"></a>
                                </li>

                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-twitter"></a>
                                </li>
                                
                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-facebook"></a>
                                </li>

                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-whatsapp"></a>
                                </li>
                            </ul>

                            <p class="copyright-text">Copyright © <i>Pyae Sithu</i>
                            <br><br>designed also by <i>Pyae Sithu</i></p>
                        </div>

                    </div>
                </div>
            </section>
        </main>

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/click-scroll.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>