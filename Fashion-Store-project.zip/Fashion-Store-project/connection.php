<?php
$con=mysql_connect("localhost","root","") or die(mysql_error());
$credb="CREATE DATABASE fashion_store";
mysql_query($credb,$con);
mysql_select_db("fashion_store",$con);
?>