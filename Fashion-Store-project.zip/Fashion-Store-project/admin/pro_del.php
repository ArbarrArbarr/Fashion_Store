<?php 
	error_reporting(1);
	include("connection.php");
    $data=mysql_query("SELECT * FROM products WHERE ID='{$_GET['pro_id']}'");
    $arr=mysql_fetch_array($data);
	
	mysql_query("DELETE FROM products WHERE ID='{$_GET['pro_id']}'");
	unlink("../image/product_images/".$arr['Image']);
    rmdir("../image/product_images/".$arr['Image']);
	echo "<script>alert('Product has been deleted successfully!')</script>";
	echo "<script>window.open('home.php','_self')</script>";
?>   