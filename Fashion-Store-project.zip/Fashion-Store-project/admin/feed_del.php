<?php
	error_reporting(1);
	include("connection.php");
	
	mysql_query("DELETE FROM feedbacks WHERE ID='{$_GET['feed_id']}'");
	echo "<script>alert('Feedback has been deleted successfully!')</script>";
	echo "<script>window.open('feedback.php','_self')</script>";
?>

		
        