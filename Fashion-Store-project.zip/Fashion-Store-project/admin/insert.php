<?php
error_reporting(1);
session_start();
include("connection.php");

if($_SESSION['name']=="")
{
    header("location:index.php");
}else
{
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "../image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <link href="../css/bootstrap-icons.css" rel="stylesheet">

        <link href="../css/templatemo-ebook-landing.css" rel="stylesheet">

        <style>
            table{
                margin-bottom:50px;          
                border-radius:13px;
                outline:5px solid #f4a261;
            }

            #guide{
                text-align:right;
            }

            #input{
                width:279px;
                height:40px;
                margin-left:25px;
                margin-bottom:15px;
                margin-top:15px;
            }

            #subinput{
                height:40px;
                background-color: var(--custom-btn-bg-color);
                border-radius: var(--border-radius-large);
                box-shadow: none;
                color: white;
                width:30%;
                padding-top: 10px;
                padding-bottom: 13px;
                padding-right: 30px;
                padding-left: 30px;
                margin-top:20px;
                margin-bottom:20px;
                outline: none;
                border:none;
            }

            #subinput:hover{
                background-color: #E76F51;
            }

            option{
                text-align:center;
                background:gray;
            }
        </style>

    </head>
    
    <body>

        <main>

            <div class= "navmain"><nav class="navbar navbar-expand-lg">
                <div class="container">
                    <a id="logo" class="navbar-brand" href="home.php">
                        <image src="../image/letter-a1.png" width="70%" height="70%">
                    </a>
                    <a class="navbar-brand" href="home.php">
                        <span id="com-name">Arbarr Arbarr</span>
                    </a>

                    <p>Admin-page</p>
    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        
                        <div id="vap" class="d-none d-lg-block">
                            <a href="../index.php" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                <i class="btn-icon bi-file-ppt"></i>
                                <span>View as Public</span><!-- duplicated above one for mobile -->
                            </a>
                        </div>
                    </div>
                </div>
            </nav></div>
            

            <section class="hero-section d-flex justify-content-center align-items-center" id="home">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12 mb-5 pb-5 pb-lg-0 mb-lg-0">

                            <h6 id="h61">Your Fashion, Your Choice</h6>

                            <a href="home.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Products</a>

                            <a href="order.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Orders</a>
                        
                            <a href="feedback.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Feedbacks</a>

                        </div>

                        <div class="hero-image-wrap col-lg-6 col-12 mt-3 mt-lg-0">
                            <img src="../image/pre.jpg" width="400px" height="800px" style="border:5px solid var(--custom-btn-bg-color); border-radius: 10px;" class="hero-image img-fluid" alt="fashion">
                        </div>

                    </div>
                </div>
            </section>


            <section class="featured-section">
                
            </section>

            <section class="py-lg-5"></section>

            <section>
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12 text-center">
                            <h6 style="padding-right: 650px; padding-bottom:50px; font-size: x-large;">New products can be added below</h6>

                            <h4 style="font-size: xxx-large; font-weight:bold; color:#f4a261;" id="feedbacks">Add new product</h4>
                        </div>

                        <div class="col-lg-12 col-12" >

<!------------------------------------------------ insert-php start ------------------------------------------------------>

<?php
mysql_query("CREATE TABLE products
(
ID INT(10) AUTO_INCREMENT PRIMARY KEY,
Product_name VARCHAR(100) NOT NULL,
Image VARCHAR(255) NOT NULL,
Category VARCHAR(20) NOT NULL,
Price VARCHAR(20) NOT NULL,
Gender VARCHAR(10) NOT NULL
)");

extract($_POST);
if($sub4)
{
    $image=$_FILES['file']['name'];
    if(mysql_query("INSERT INTO products VALUES('','$name','$image','$cate','$price','$gen')"))
    {
        mkdir("image/product_images");
        move_uploaded_file($_FILES['file']['tmp_name'],"../image/product_images/".$_FILES['file']['name']);
        header('location:home.php');
    }
}

}
?>

<!------------------------------------------------ insert-php end ------------------------------------------------------>

                            <form method="post" enctype="multipart/form-data">
                            <table width="50%" id="table" align="center">
                                <tr>
                                    <td width="35%" id="guide"><b>Product-name:</b></td>
                                    <td width="65%"><input id="input" type="text" name="name" required></td>
                                </tr>

                                <tr>
                                    <td width="35%" id="guide"><b>Product-image:</b></td>
                                    <td width="65%"><input id="input" type="file" name="file" required></td>
                                </tr>

                                <tr>
                                    <td width="35%" id="guide"><b>Category:</b></td>
                                    <td width="65%">
                                        <select id="input" name="cate">
                                                                                        
                                            <option>Street</option>
                                            <option selected>Classic</option>
                                            <option>Cyber</option>
                                            <option>Hiphop</option>
                                            <option>Business</option>

                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <td width="35%" id="guide"><b>Price:</b></td>
                                    <td width="65%"><input id="input" type="number" name="price" required></td>
                                </tr>

                                <tr>
                                    <td width="35%" id="guide"><b>Gender:</b></td>
                                    <td width="65%">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        For men<input id="checkbox" type="radio" name="gen" value="men" required>&nbsp;&nbsp;
                                        For women<input type="radio" name="gen" value="women" required>&nbsp;&nbsp;
                                        Duel<input type="radio" name="gen" value="duel" required>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2">
                                        <div align="center">
                                            <input id="subinput" type="submit" value="Add" name="sub4">
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            </form>
                        </div>

                    </div>
                </div>
            </section>
            
        </main>

        <!-- JAVASCRIPT FILES -->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.sticky.js"></script>
        <script src="../js/click-scroll.js"></script>
        <script src="../js/custom.js"></script>

    </body>
</html>