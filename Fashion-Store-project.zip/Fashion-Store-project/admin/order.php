<?php
error_reporting(1);
session_start();
include("connection.php");

if($_SESSION['name']=="")
{
    header("location:index.php");
}

?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "../image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <link href="../css/bootstrap-icons.css" rel="stylesheet">

        <link href="../css/templatemo-ebook-landing.css" rel="stylesheet">

        <style>
            #table{
                margin-bottom:50px;          
                border-radius:13px;
                outline:5px solid #f4a261;
            }

            td{
                text-align:center;
                border-bottom:1px solid gray;
                border-right:0.5px solid gray;
                padding-bottom:25px;
            }

            th{
                color:#E76F51;
                font-size:large;
                text-align:center;
                border-bottom:2px solid gray;
                border-right:0.5px solid gray;
                padding-bottom:25px;
            }

            td:last-child{
                border-right:none;
            }

            th:last-child{
                border-right:none;
            }

            tr:nth-child(even) {
                background: #bfbfbfff;
            }

            h2{
                margin-top:10px;
                margin-bottom:10%;
            }

            #del{
                color:red;
            }

            #del:hover{
                text-decoration:underline;
            }
        </style>

    </head>
    
    <body>

        <main>

            <div class= "navmain"><nav class="navbar navbar-expand-lg">
                <div class="container">
                    <a id="logo" class="navbar-brand" href="home.php">
                        <image src="../image/letter-a1.png" width="70%" height="70%">
                    </a>
                    <a class="navbar-brand" href="home.php">
                        <span id="com-name">Arbarr Arbarr</span>
                    </a>

                    <p>Admin-page</p>
    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        
                        <div id="vap" class="d-none d-lg-block">
                            <a href="../index.php" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                <i class="btn-icon bi-file-ppt"></i>
                                <span>View as Public</span><!-- duplicated above one for mobile -->
                            </a>
                        </div>
                    </div>
                </div>
            </nav></div>
            

            <section class="hero-section d-flex justify-content-center align-items-center" id="home">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12 mb-5 pb-5 pb-lg-0 mb-lg-0">

                            <h6 id="h61">Your Fashion, Your Choice</h6>

                            <a href="home.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Products</a>

                            <a href="insert.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">Insert Products</a>
                        
                            <a href="feedback.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Feedbacks</a>

                        </div>

                        <div class="hero-image-wrap col-lg-6 col-12 mt-3 mt-lg-0">
                            <img src="../image/pre.jpg" width="400px" height="800px" style="border:5px solid var(--custom-btn-bg-color); border-radius: 10px;" class="hero-image img-fluid" alt="fashion">
                        </div>

                    </div>
                </div>
            </section>


            <section class="featured-section">
                
            </section>

            <section class="py-lg-5"></section>

            <section>
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-15 text-center">
                            <h6 style="padding-right: 650px; padding-bottom:50px; font-size: x-large;">Orders are below</h6>

                            <h4 style="font-size: xxx-large; font-weight:bold; color:#f4a261;" id="feedbacks">Orders</h4>
                        </div>

                        <div class="col-lg-12 col-15" >
                            <table width="100%" id="table">
                                <tr>
                                    <th width="17%"><b>Customer-name</b></th>
                                    <th width="17%"><b>Product-name</b></th>
                                    <th width="7%"><b>Ord-No</b></th>
                                    <th width="9%"><b>Price</b></th>

                                    <th width="4%"><b>Qty</b></th>
                                    <th width="9%"><b>Payment</b></th>
                                    <th width="20%"><b>Email</b></th>
                                    <th width="9%"><b>Phone</b></th>

                                    <th width="6%"><b>Cancel</b></th>
                                </tr>

                                <?php
                                    $datafb=mysql_query("SELECT * FROM orders ORDER BY ID DESC");
                                    while($arr1=mysql_fetch_assoc($datafb))
                                    {
                                        $or_id=$arr1["ID"];
                                ?>

                                <tr>
                                    <td><?php echo $arr1["Customer_name"] ; ?></td>
                                    <td><?php echo $arr1["Product_name"] ; ?></td>
                                    <td><?php echo $arr1["Ordno"] ; ?></td>
                                    <td><?php echo $arr1["Price"] ; ?> ks</td>

                                    <td><?php echo $arr1["Quantity"] ; ?></td>
                                    <td><?php echo $arr1["Payment"] ; ?> ks</td>
                                    <td><?php echo $arr1["Email"] ; ?></td>
                                    <td><?php echo $arr1["Phone"] ; ?></td>

                                    <td><a id="del" href="or_del.php?or_id=<?php echo $or_id ; ?>">Delete</a></td>
                                </tr>

                                <?php
                                    }                                
                                ?>
                            </table>
                        </div>

                    </div>
                </div>
            </section>
        </main>

        <!-- JAVASCRIPT FILES -->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.sticky.js"></script>
        <script src="../js/click-scroll.js"></script>
        <script src="../js/custom.js"></script>

    </body>
</html>