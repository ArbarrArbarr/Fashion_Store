<?php
error_reporting(1);
session_start();
include("connection.php");

if($_SESSION['name']=="")
{
    header("location:index.php");
}
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "../image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <link href="../css/bootstrap-icons.css" rel="stylesheet">

        <link href="../css/templatemo-ebook-landing.css" rel="stylesheet">

        <style>
            
            #table{
                margin-bottom:50px;          
                border-radius:13px;
                outline:5px solid #f4a261;
            }

            td{
                text-align:center;
                border-bottom:1px solid gray;
                padding-bottom:25px;
            }

            th{
                color:#E76F51;
                font-size:large;
                text-align:center;
                border-bottom:2px solid gray;
                padding-bottom:25px;
            }

            #del{
                color:red;
            }

            #del:hover{
                border:2px solid red;
                font-weight:bold;
            }
        </style>

    </head>
    
    <body>

        <main>

            <div class= "navmain"><nav class="navbar navbar-expand-lg">
                <div class="container">
                    <a id="logo" class="navbar-brand" href="home.php">
                        <image src="../image/letter-a1.png" width="70%" height="70%">
                    </a>
                    <a class="navbar-brand" href="home.php">
                        <span id="com-name">Arbarr Arbarr</span>
                    </a>

                    <p>Admin-page</p>
    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        
                        <div id="vap" class="d-none d-lg-block">
                            <a href="../index.php" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                <i class="btn-icon bi-file-ppt"></i>
                                <span>View as Public</span><!-- duplicated above one for mobile -->
                            </a>
                        </div>
                    </div>
                </div>
            </nav></div>
            

            <section class="hero-section d-flex justify-content-center align-items-center" id="home">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12 mb-5 pb-5 pb-lg-0 mb-lg-0">

                            <h6 id="h61">Your Fashion, Your Choice</h6>

                            <a href="#products" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Products</a>

                            <a href="insert.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">Insert Products</a>
                        
                            <a href="order.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Orders</a>

                            <a href="feedback.php" class="link link--kale smoothscroll" style="border-left:2px solid #E76F51;">View Feedbacks</a>
                        </div>

                        <div class="hero-image-wrap col-lg-6 col-12 mt-3 mt-lg-0">
                            <img src="../image/pre.jpg" width="400px" height="800px" style="border:5px solid var(--custom-btn-bg-color); border-radius: 10px;" class="hero-image img-fluid" alt="fashion">
                        </div>

                    </div>
                </div>
            </section>


            <section class="featured-section">
                
            </section>

            <section class="py-lg-5"></section>

            <section>
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12 text-center">
                            <h6 style="padding-right: 650px; padding-bottom:50px; font-size: x-large;">Welcome to <strong><i>Admin-page</i></strong><br>Products are below</h6>
                            
                            <h4 style="font-size: xxx-large; font-weight:bold; color:#f4a261;" id="products">Products</h4>
                            
                        </div>

<div class="col-lg-4 col-12" >
    <nav id="navbar-example3" class="h-100 flex-column align-items-stretch">
        <nav class="nav nav-pills flex-column">

            <a class="nav-link smoothscroll" href="#item-1"><strong>Street Fashion</strong></a>

            <a class="nav-link smoothscroll" href="#item-2"><strong>Classic Fashion</strong></a>

            <a class="nav-link smoothscroll" href="#item-3"><strong>Cyber Fashion</strong></a>

            <a class="nav-link smoothscroll" href="#item-4"><strong>Hiphop Fashion</strong></a>

            <a class="nav-link smoothscroll" href="#item-5"><strong>Business Casual</strong></a>
        </nav>
    </nav>
</div>

<div class="col-lg-8 col-12">
    <div data-bs-spy="scroll" data-bs-target="#navbar-example3" data-bs-smooth-scroll="true" class="scrollspy-example-2" tabindex="0">
        
        <div class="scrollspy-example-item" id="item-1">

            <h3 align="center" style="color:#F4A261;">Street Fashion</h3>
            
            <table width="100%" id="table">
                <tr>
                    <th width="31%"><b>Name</b></th>
                    <th width="25%"><b>Image</b></th>
                    <th width="20%"><b>Price</b></th>
                    <th width="10%"><b>Gender</b></th>
                    <th width="6%"><b>Update</b></th>
                    <th width="6%"><b>Delete</b></th>
                </tr>

                <?php
                    $datafb=mysql_query("SELECT * FROM products WHERE Category='Street' ORDER BY ID DESC");
                    while(list($pro_id, $pro_name, $pro_img, $pro_cat, $pro_price, $pro_gen)=mysql_fetch_array($datafb))
                    {
                ?>

                <tr>
                    <td><b><?php echo $pro_name ; ?></b></td>
                    <td><img src="../image/product_images/<?php echo $pro_img ; ?>" width="100%"></td>
                    <td><?php echo $pro_price ; ?> ks</td>
                    <td><?php echo $pro_gen ; ?></td>
                    <td><a id="del" href="pro_edit.php?pro_id=<?php echo $pro_id ;?>">Update</a></td>
                    <td><a id="del" href="pro_del.php?pro_id=<?php echo $pro_id ;?>, pro_img=<?php echo $pro_img ;?>">Delete</a></td>
                </tr>

                <?php
                    }                                
                ?>
            </table>

        </div>

        <div class="scrollspy-example-item" id="item-2">

            <h3 align="center" style="color:#F4A261;">Classic Fashion</h3>
            
            <table width="100%" id="table">
                <tr>
                    <th width="31%"><b>Name</b></th>
                    <th width="25%"><b>Image</b></th>
                    <th width="20%"><b>Price</b></th>
                    <th width="10%"><b>Gender</b></th>
                    <th width="6%"><b>Update</b></th>
                    <th width="6%"><b>Delete</b></th>
                </tr>

                <?php
                    $datafb=mysql_query("SELECT * FROM products WHERE Category='Classic' ORDER BY ID DESC");
                    while(list($pro_id, $pro_name, $pro_img, $pro_cat, $pro_price, $pro_gen)=mysql_fetch_array($datafb))
                    {
                ?>

                <tr>
                    <td><b><?php echo $pro_name ; ?></b></td>
                    <td><img src="../image/product_images/<?php echo $pro_img ; ?>" width="100%"></td>
                    <td><?php echo $pro_price ; ?> ks</td>
                    <td><?php echo $pro_gen ; ?></td>
                    <td><a id="del" href="pro_edit.php?pro_id=<?php echo $pro_id ;?>">Update</a></td>
                    <td><a id="del" href="pro_del.php?pro_id=<?php echo $pro_id ;?>, pro_img=<?php echo $pro_img ;?>">Delete</a></td>
                </tr>

                <?php
                    }                                
                ?>
            </table>
            
        </div>

        <div class="scrollspy-example-item" id="item-3"> 

            <h3 align="center" style="color:#F4A261;">Cyber Fashion</h3>
            
            <table width="100%" id="table">
                <tr>
                    <th width="31%"><b>Name</b></th>
                    <th width="25%"><b>Image</b></th>
                    <th width="20%"><b>Price</b></th>
                    <th width="10%"><b>Gender</b></th>
                    <th width="6%"><b>Update</b></th>
                    <th width="6%"><b>Delete</b></th>
                </tr>

                <?php
                    $datafb=mysql_query("SELECT * FROM products WHERE Category='Cyber' ORDER BY ID DESC");
                    while(list($pro_id, $pro_name, $pro_img, $pro_cat, $pro_price, $pro_gen)=mysql_fetch_array($datafb))
                    {
                ?>

                <tr>
                    <td><b><?php echo $pro_name ; ?></b></td>
                    <td><img src="../image/product_images/<?php echo $pro_img ; ?>" width="100%"></td>
                    <td><?php echo $pro_price ; ?> ks</td>
                    <td><?php echo $pro_gen ; ?></td>
                    <td><a id="del" href="pro_edit.php?pro_id=<?php echo $pro_id ;?>">Update</a></td>
                    <td><a id="del" href="pro_del.php?pro_id=<?php echo $pro_id ;?>, pro_img=<?php echo $pro_img ;?>">Delete</a></td>
                </tr>

                <?php
                    }                                
                ?>
            </table>                                
    
        </div>

        <div class="scrollspy-example-item" id="item-4">

            <h3 align="center" style="color:#F4A261;">Hiphop Fashion</h3>
            
            <table width="100%" id="table">
                <tr>
                    <th width="31%"><b>Name</b></th>
                    <th width="25%"><b>Image</b></th>
                    <th width="20%"><b>Price</b></th>
                    <th width="10%"><b>Gender</b></th>
                    <th width="6%"><b>Update</b></th>
                    <th width="6%"><b>Delete</b></th>
                </tr>

                <?php
                    $datafb=mysql_query("SELECT * FROM products WHERE Category='Hiphop' ORDER BY ID DESC");
                    while(list($pro_id, $pro_name, $pro_img, $pro_cat, $pro_price, $pro_gen)=mysql_fetch_array($datafb))
                    {
                ?>

                <tr>
                    <td><b><?php echo $pro_name ; ?></b></td>
                    <td><img src="../image/product_images/<?php echo $pro_img ; ?>" width="100%"></td>
                    <td><?php echo $pro_price ; ?> ks</td>
                    <td><?php echo $pro_gen ; ?></td>
                    <td><a id="del" href="pro_edit.php?pro_id=<?php echo $pro_id ;?>">Update</a></td>
                    <td><a id="del" href="pro_del.php?pro_id=<?php echo $pro_id ;?>, pro_img=<?php echo $pro_img ;?>">Delete</a></td>
                </tr>

                <?php
                    }                                
                ?>
            </table>

        </div>

        <div class="scrollspy-example-item" id="item-5">

            <h3 align="center" style="color:#F4A261;">Business Casual</h3>
            
            <table width="100%" id="table">
                <tr>
                    <th width="31%"><b>Name</b></th>
                    <th width="25%"><b>Image</b></th>
                    <th width="20%"><b>Price</b></th>
                    <th width="10%"><b>Gender</b></th>
                    <th width="6%"><b>Update</b></th>
                    <th width="6%"><b>Delete</b></th>
                </tr>

                <?php
                    $datafb=mysql_query("SELECT * FROM products WHERE Category='Business' ORDER BY ID DESC");
                    while(list($pro_id, $pro_name, $pro_img, $pro_cat, $pro_price, $pro_gen)=mysql_fetch_array($datafb))
                    {
                ?>

                <tr>
                    <td><b><?php echo $pro_name ; ?></b></td>
                    <td><img src="../image/product_images/<?php echo $pro_img ; ?>" width="100%"></td>
                    <td><?php echo $pro_price ; ?> ks</td>
                    <td><?php echo $pro_gen ; ?></td>
                    <td><a id="del" href="pro_edit.php?pro_id=<?php echo $pro_id ;?>">Update</a></td>
                    <td><a id="del" href="pro_del.php?pro_id=<?php echo $pro_id ;?>, pro_img=<?php echo $pro_img ;?>">Delete</a></td>
                </tr>

                <?php
                    }                                
                ?>
            </table>
            
        </div>
    </div>
</div>

                    </div>
                </div>
            </section>
            
        </main>

        <!-- JAVASCRIPT FILES -->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.sticky.js"></script>
        <script src="../js/click-scroll.js"></script>
        <script src="../js/custom.js"></script>

    </body>
</html>