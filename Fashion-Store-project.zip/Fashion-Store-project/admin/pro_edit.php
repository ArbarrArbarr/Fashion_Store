<?php
error_reporting(1);
session_start();
include("connection.php");

if($_SESSION['name']=="")
{
    header("location:index.php");
}

$data=mysql_query("SELECT * FROM products WHERE ID='{$_GET['pro_id']}'");
$arr=mysql_fetch_array($data);
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "../image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <link href="../css/bootstrap-icons.css" rel="stylesheet">

        <link href="../css/templatemo-ebook-landing.css" rel="stylesheet">

        <style>
            table{        
                position:block;
                margin-top:10%;
                border-radius:13px;
                outline:5px solid #f4a261;
            }

            #guide{
                text-align:right;
            }

            #input{
                width:279px;
                height:40px;
                margin-left:25px;
                margin-bottom:15px;
                margin-top:15px;
            }

            #subinput{
                height:40px;
                background-color: var(--custom-btn-bg-color);
                border-radius: var(--border-radius-large);
                box-shadow: none;
                color: white;
                width:30%;
                padding-top: 10px;
                padding-bottom: 13px;
                padding-right: 30px;
                padding-left: 30px;
                margin-top:20px;
                margin-bottom:20px;
                outline: none;
                border:none;
            }

            #subinput:hover{
                background-color: #E76F51;
            }

            option{
                text-align:center;
                background:gray;
            }
        </style>
    </head>

    <body>
<!--------------------------------- Edit php start --------------------------------> 
<?php
extract($_POST);
if($sub6){
    mysql_query("UPDATE products SET Product_name='$name', Category='$cate', Price='$price', Gender='$gen' WHERE ID='{$_GET['pro_id']}'");
	echo "<script>alert('Item's data has been updated successfully!')</script>";
	echo "<script>window.open('home.php','_self')</script>";
}
?>
<!--------------------------------- Edit php end --------------------------------> 

        <form method="post" enctype="multipart/form-data">
            <table width="50%" id="table" align="center">
                <tr>
                    <td width="35%" id="guide"><b>Product-name:</b></td>
                    <td width="65%"><input id="input" type="text" name="name" required value="<?php echo $arr['Product_name'] ;?>"></td>
                </tr>

                <tr>
                    <td width="35%" id="guide"><b>Category:</b></td>
                    <td width="65%">
                        <select id="input" name="cate" required value="<?php echo $arr['Category'] ;?>">
                                                                                        
                            <option>Street</option>
                            <option>Classic</option>
                            <option>Cyber</option>
                            <option>Hiphop</option>
                            <option>Business</option>

                        </select>
                    </td>
                </tr>

                <tr>
                    <td width="35%" id="guide"><b>Price:</b></td>
                    <td width="65%"><input id="input" type="number" name="price" required value="<?php echo $arr['Price'] ;?>"></td>
                </tr>

                <tr>
                    <td width="35%" id="guide"><b>Gender:</b></td>
                    <td width="65%">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        For men<input type="radio" name="gen" value="men" required>&nbsp;&nbsp;
                        For women<input type="radio" name="gen" value="women" required>&nbsp;&nbsp;
                        Duel<input type="radio" name="gen" value="duel" required>
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <div align="center">
                        <input id="subinput" type="submit" value="Add" name="sub6">
                        </div>
                    </td>
                </tr>
            </table>
        </form>
    </body>