<?php
error_reporting(1);
session_start();
include("connection.php");

extract($_POST);
if($sub3)
{
    $opdb=mysql_query("SELECT * FROM user WHERE Name='$name'");
    $arr=mysql_fetch_assoc($opdb);
    if($arr["Name"] == "$name" && $arr["Password"] == "$password")
    {
        $_SESSION['name']=$name;
        header("location:home.php");
    }else
    {
        $er= "<font color='red'>Your name or password is incorrect.</font>";
    }
}
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "../image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <link href="../css/bootstrap-icons.css" rel="stylesheet">

        <link href="../css/templatemo-ebook-landing.css" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">

        <style>
            form{
                height: 370px;
                background-color:white;
                margin-left:300px;
                margin-right:300px;
                margin-top:10%;
                border:3px solid var(--custom-btn-bg-color);
                border-radius:10%;
            }

            h1{
                color: var(--custom-btn-bg-color);
                cursor:pointer;
                font-family: 'Lilita One', cursive;
            }

            body{
                box-sizing:border-box;
                background-color:pink;
            }

            #adminloginput{
                border:1px solid gray;
                border-radius:var(--border-radius-small);
                height:50px;
                width:300px;
            }

            #adminloginput:hover{
                border:2px solid #E76F51;
            }

            #div{
                margin-top:30px;
                margin-bottom:30px;
            }

            #left{
                width:25%;
                float:left;
            }

            #mid{
                width:50%;
                float:left;
            }

            #right{
                width:25%;
                float:left;
            }

            #leftgif{
                transform:scaleX(-1);
            }

            #adminloginsub{
                background-color: var(--custom-btn-bg-color);
                border-radius: var(--border-radius-large);
                box-shadow: none;
                color: white;
                width:40%;
                padding-top: 13px;
                padding-bottom: 13px;
                padding-right: 30px;
                padding-left: 30px;
                margin-top:20px;
                outline: none;
                border:none;
            }

            #adminloginsub:hover{
                background-color: #E76F51;
            }

            a{
                text-decoration:underline;
            }
        </style>

    </head>
    
    <body>

        <div>
            <center>
            <form method="post">

            <div>
                <h1>Admin Login Form</h1>
            </div>

            <div>
                <div id="left">
                    <image id="leftgif" src="image/giphy.gif" width="100%" height="auto">
                </div>

                <div id="mid">
                    <div id="div">
                        <input type="text" name="name" id="adminloginput" placeholder="Your Name" required>
                    </div>

                    <div id="div">
                        <input type="password" name="password" id="adminloginput" placeholder="Password" required>
                    </div>

                    <div id="div">
                        <?php echo  $er ; ?>                                     

                        <input name="sub3" type="submit" id="adminloginsub" value="Login"><br>
                        <a href="setpass.php">want to change password?</a>
                    </div>
                </div>

                <div id="right">
                    <image id="rightgif" src="image/giphy.gif" width="100%" height="auto">
                </div>
            </div>

            </form>
            </center>
        <div>

        <!-- JAVASCRIPT FILES -->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.sticky.js"></script>
        <script src="../js/click-scroll.js"></script>
        <script src="../js/custom.js"></script>

    </body>
</html>