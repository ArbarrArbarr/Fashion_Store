<?php
	error_reporting(1);
	include("connection.php");
	
	mysql_query("DELETE FROM orders WHERE ID='{$_GET['or_id']}'");
	echo "<script>alert('Order has been deleted successfully!')</script>";
	echo "<script>window.open('order.php','_self')</script>";
?>

		
        