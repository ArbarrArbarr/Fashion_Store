<?php
    session_start();
    error_reporting(1);
    include("connection.php");
    $cus_email=$_REQUEST['reg_email'];
    
    $cusname=$_SESSION['$cusname'];
    $Product_name=$_SESSION['$Product_name'];
    $Product_Price=$_SESSION['$Product_Price'];
    $quantity=$_SESSION['$quantity'];
    $ordno=$_SESSION['$ordno'];
    $pay=$_SESSION['$pay'];
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "../image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <link href="../css/bootstrap-icons.css" rel="stylesheet">

        <link href="../css/templatemo-ebook-landing.css" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">

        <style>
            #font{
                color:white;
                font-weight:bold;
                font-family: 'Varela Round', sans-serif;
            }

            #font1{
                color: green;
                font-weight:bold;
                font-family: 'Varela Round', sans-serif;
            }

            h1{
                margin-top:30px;
                margin-bottom:80px;
                font-size:xxx-large;
            }

            p{
                font-size:medium;
            }

            a{
                cursor:pointer;
                color:black;
                text-decoration:underline;
            }

            a:hover{
                color: green;
                font-weight: bold;
            }
        </style>
    </head>
    
    <body bgcolor="#F4A261">

        <div>
            <center>
                <h1 id="font">Ordered Completely</h1>

                <p id="font"><?php echo "$cusname has ordered $Product_name in quantity of ($quantity) for $Product_Price per one."; ?></p>
                <p id="font"><?php echo "Total payment is $pay ks."; ?></p>
                <p id="font"><?php echo "Order-No :"."&nbsp;&nbsp;&nbsp;&nbsp;".$ordno; ?></p>
                <p id="font1">(By Admin) "Thank you so much! Come again..." (By Admin)</p>

                <a href="registered.php?reg_email=<?php echo $cus_email; ?>">Go back</a>

                <div>
                    <image src="image/giphy1.gif" width="20%" height="auto">
                </div>
            </center>
        <div>

        <!-- JAVASCRIPT FILES -->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.sticky.js"></script>
        <script src="../js/click-scroll.js"></script>
        <script src="../js/custom.js"></script>

    </body>
</html>