<?php
session_start();
if($_SESSION['user_email']=="")
{
    header("location:index.php");
}

error_reporting(1);
include("connection.php");
$pd_id=$_REQUEST['pd_id'];
$cus_email=$_REQUEST['reg_email'];

mysql_query("CREATE TABLE orders
(
    ID INT(10) AUTO_INCREMENT PRIMARY KEY,
    Customer_name VARCHAR(30) NOT NULL,
    Product_name VARCHAR(50) NOT NULL,
    Ordno VARCHAR(10) NOT NULL,
    Price VARCHAR(10) NOT NULL,
    Quantity INT(100) NOT NULL,
    Payment INT(100) NOT NULL,
    Email VARCHAR(50) NOT NULL,
    Phone BIGINT(20) NOT NULL,
    Address VARCHAR(100) NOT NULL
)");
    $opdb2=mysql_query("SELECT * FROM products WHERE ID='$pd_id'");
    $arr2=mysql_fetch_assoc($opdb2);
    $Product_name=$arr2['Product_name'];
    $Product_Price=$arr2['Price'];

?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arbarr Arbarr-Fashion Store</title>
        <link rel="icon" type="image/x-icon" href= "../image/letter-a1.png">

        <!-- CSS FILES -->

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link href="css/templatemo-ebook-landing.css" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">

        <script>
            function od_fail(){
                alert("Order Failed!");
            }
        </script>

        <style>
            form{
                height: 680px;
                background-color:white;
                margin-left:300px;
                margin-right:300px;
                margin-top:5%;
                margin-bottom:5%;
                border:3px solid var(--custom-btn-bg-color);
                border-radius:10%;
                font-size:12px;
            }

            h1{
                color: var(--custom-btn-bg-color);
                cursor:pointer;
                font-family: 'Lilita One', cursive;
            }

            body{
                box-sizing:border-box;
                background-color:pink;
            }

            #adminloginput{
                border:1px solid gray;
                border-radius:var(--border-radius-small);
                height:30px;
                width:200px;
            }

            #adminloginput:hover{
                border:2px solid #E76F51;
            }

            #textarea{    
                border:1px solid gray;
                border-radius:var(--border-radius-small);
                height:100px;
                width:230px;
            }

            #textarea:hover{
                border:2px solid #E76F51;
            }

            #div{
                margin-top:30px;
                margin-bottom:30px;
                text-align:right;
            }

            #div:last-child{
                text-align:center;
            }

            #left{
                width:25%;
                float:left;
            }

            #mid{
                width:50%;
                float:left;
            }

            #right{
                width:25%;
                float:left;
            }

            #leftgif{
                transform:scaleX(-1);
            }

            #ordersub{
                background-color: var(--custom-btn-bg-color);
                border-radius: var(--border-radius-large);
                box-shadow: none;
                color: white;
                width:40%;
                padding-top: 13px;
                padding-bottom: 13px;
                padding-right: 30px;
                padding-left: 30px;
                margin-top:20px;
                outline: none;
                border:none;
            }

            #ordersub:hover{
                background-color: #E76F51;
            }

            a{
                text-decoration:none;
            }
        </style>

    </head>
    
    <body>

<?php
extract($_POST);
if($sub6)
{
    if($cus_email == $email)
    {
        $ordno=ord.rand(1000,9999);
        $pay=$Product_Price * $quantity; 
        mysql_query("INSERT INTO orders VALUES('','$cusname','$Product_name','$ordno','$Product_Price','$quantity','$pay','$email','$mob','$address')");
        $_SESSION['$cusname']=$cusname;
        $_SESSION['$Product_name']=$Product_name;
        $_SESSION['$Product_Price']=$Product_Price;
        $_SESSION['$quantity']=$quantity;
        $_SESSION['$ordno']=$ordno;
        $_SESSION['$pay']=$pay;
        header("location:order_success.php?reg_email=$cus_email");
    }else
    {
        $order_fail="<font color='red'>Please <b>CHECK AGAIN! </b>That's not your e-mail.</font>";
        echo "<script> od_fail() </script>" ;
    }
}
?>

        <div>
            <center>
            <form method="post">

            <div>
                <h1>Order Form</h1>
            </div>

            <div>
                <div id="left">
                    <image id="leftgif" src="admin/image/giphy.gif" width="100%" height="auto">
                </div>

                <div id="mid">

                    <div id="div">
                        Your name :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="cusname" id="adminloginput" required>
                    </div>

                    <div id="div">
                        Product-name :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" id="adminloginput" value="<?php echo  $Product_name;?>" disabled required>
                    </div>
                    
                    <div id="div">
                        Price :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" id="adminloginput" value="<?php echo  $Product_Price.' ks';?>" disabled required>
                    </div>

                    <div id="div">
                        Quantity :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="number" name="quantity" id="adminloginput" value="1" min="1" step="1" required>
                    </div>
                    
                    <div id="div">
                        Email :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="email" name="email" id="adminloginput" required>
                    </div>

                    <div id="div">
                        Moblie number :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="mob" id="adminloginput" required>
                    </div>

                    <div id="div">
                        address :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <textarea type="text" name="address" id="textarea" required></textarea>
                    </div>

                    <div id="div">
                        <?php echo  $order_fail ; ?>        

                        <a href="registered.php?reg_email=<?php echo $cus_email; ?>" type="button" id="ordersub">Cancel</a>
                        <input name="sub6" type="submit" id="ordersub" value="Order">
                    </div>
                </div>

                <div id="right">
                    <image src="admin/image/giphy.gif" width="100%" height="auto">
                </div>
            </div>

            </form>
            </center>
        <div>

        <!-- JAVASCRIPT FILES -->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.sticky.js"></script>
        <script src="../js/click-scroll.js"></script>
        <script src="../js/custom.js"></script>

    </body>
</html>
