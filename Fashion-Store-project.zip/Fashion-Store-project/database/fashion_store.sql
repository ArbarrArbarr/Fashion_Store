-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 17, 2023 at 07:00 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fashion_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE IF NOT EXISTS `feedbacks` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Feedback` varchar(70) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`ID`, `Name`, `Email`, `Feedback`) VALUES
(1, 'Mg Nu', 'mgnu@gmail.com', 'hi'),
(2, 'some one', 'mgnu@gmail.com', 'Hello'),
(3, 'Mg Nu', 'mgnu@gmail.com', 'hello'),
(5, 'ad', 'mgnu@gmail.com', 'Hee hee hee'),
(6, 'ad', 'mgnu@gmail.com', 'Softlay articles provide with quick solutions covering multimedia, pro'),
(7, 'admin', 'mgnu@gmail.com', 'nfgnsf');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Customer_name` varchar(30) NOT NULL,
  `Product_name` varchar(50) NOT NULL,
  `Ordno` varchar(10) NOT NULL,
  `Price` varchar(10) NOT NULL,
  `Quantity` int(100) NOT NULL,
  `Payment` int(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` bigint(20) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ID`, `Customer_name`, `Product_name`, `Ordno`, `Price`, `Quantity`, `Payment`, `Email`, `Phone`, `Address`) VALUES
(26, 'Mg Nu', 'Russia hoodie', 'ord7220', '16000', 1, 16000, 'mgnu@gmail.com', 9876546543, 'Dagon(East)\r\nBlah Blah Blah'),
(27, 'Mg Nu', 'Star graphic sweater', 'ord8543', '9000', 5, 45000, 'mgnu@gmail.com', 9876546543, 'Dagon(East)\r\nBlah Blah Blah'),
(28, 'Mg Nu', 'Trip Nyc skull bondage pant', 'ord3031', '27000', 1, 27000, 'mgnu@gmail.com', 987654332, 'Dagon(East)\r\nBlah Blah Blah');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Product_name` varchar(100) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Category` varchar(20) NOT NULL,
  `Price` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `Product_name`, `Image`, `Category`, `Price`, `Gender`) VALUES
(1, '9Tewnty cyber hat', 'do moa 3d medical animation, medical illustration, and 3d surgical animation.jpg', 'Cyber', '12200', 'duel'),
(2, 'on-off call_black hoodie', 'y2k aesthetic letter embroidery hoodies women harajuku long sleeve zip up sweatshirts vintage punk loose hooded jackets streetwear y2k clothes - ea00223-apricot, m.jpg', 'Hiphop', '15000', 'women'),
(3, 'on-off call_white hoodie', 'y2k aesthetic women letter print hoodies preppy aesthetic autumn winter retro loose zip up hooded sweatshirts female casual long sleeve sweatshirt coats - stm149-grey, s.jpg', 'Hiphop', '15000', 'women'),
(4, 'Trip Nyc skull bondage pant', 'Tripp NYC Skull Bondage Pants [Black_White] - 3XL.jpg', 'Hiphop', '27000', 'duel'),
(5, 'Star graphic sweater', 'Y2K Stars Graphic Sweaters - Black _ L.jpg', 'Classic', '9000', 'duel'),
(6, 'landscape hoodie', 'Suit Landscape Hoodie By Britto.jpg', 'Street', '15000', 'men'),
(7, 'Landscape hoodie', 'Landscape Night Hoodie By Britto.jpg', 'Street', '15000', 'men'),
(8, 'set for outfit', 'download.png', 'Classic', '50000', 'men'),
(9, 'Designed T shirt', '61Fbr7CmNFS._AC_SL1500_.jpg', 'Classic', '5000', 'men'),
(10, 'UY1100', '41YXM6cTglL._AC_UY1100_.jpg', 'Cyber', '23000', 'women'),
(11, 'guitar hoodie', '697860983_max.jpg', 'Hiphop', '9000', 'duel'),
(12, 'simple shirt', '1634583998-screen-shot-2021-10-18-at-3-06-17-pm-1634583987.png', 'Classic', '6000', 'men'),
(13, 'Clibjn', 'clibjn7zw0009lf0f52532a84_1.jpg', 'Hiphop', '8000', 'men'),
(14, 'cyber pant mega eyes', 'a62905d74af56e03739fa694b56451ce.png', 'Cyber', '25000', 'men'),
(15, 'Punk rave', 'punk-rave-minikleid-cyber-geisha~5.jpg', 'Cyber', '29000', 'women'),
(16, 'gold circle hoodie', 'clibjkxsv000fms0fsdqoea0t_1.jpg', 'Street', '16000', 'men'),
(17, 'Russia hoodie', 'Russia-Badge-Gold-Eagle-Printing-Autum-Winter-Men-s-Fashion-Zipper-Hoodie-High-Necked-Hooded-Zip.jpg', 'Street', '16000', 'men'),
(18, 'Lighting sweater', 'il_fullxfull.3984651088_n2kw.jpg', 'Street', '15000', 'duel'),
(19, 'D26', 'D2647C22-2.jpg', 'Classic', '18000', 'women'),
(20, 'b1175', 'b1175c77963a310feeffab8fd03ed20b--cool-jackets-black-coats.jpg', 'Cyber', '32000', 'men'),
(21, 'Classic strip', 'Cotton-Polo-t-shirts-for-Men-Casual-Solid-Color-Slim-Fit-Mens-Polos-New-Summer-Fashion.jpg_640x640.jpg', 'Business', '13000', 'men'),
(22, 'Business pant coffee color', '1.jpg', 'Business', '21000', 'men'),
(23, 'Business pant gray color', '1 (1).jpg', 'Business', '21000', 'men'),
(24, 'Business pant black color', '1 (2).jpg', 'Business', '21000', 'men'),
(25, 'business suit', '0d1c9e12094e038ef9b4fa2d9d104528--mens-clothing-stores-mens-clothing.jpg', 'Business', '32000', 'men'),
(26, 'Lady shoe', 'timeless-women-style-218384-1653503609662-main.700x0c.jpg', 'Business', '18000', 'women'),
(27, 'girl office pants ', '511+O9JIAlL._AC_SL1500_.jpg', 'Business', '17000', 'women');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `Name` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Phone` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Name`, `Email`, `Password`, `Phone`) VALUES
('Mg Nu', 'mgnu@gmail.com', '1234', 987654321);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Name` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Name`, `Password`) VALUES
('admin', '123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
